package cn.bavelee.multiselectcalendar;

public interface OnDateCheckedListener {
    void onDateChecked(int position, DateItem dateItem);
}
