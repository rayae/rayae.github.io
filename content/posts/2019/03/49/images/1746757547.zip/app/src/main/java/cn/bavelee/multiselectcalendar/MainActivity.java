package cn.bavelee.multiselectcalendar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    GridView gridView;
    List<DateItem> dateItemList;
    DateAdapter dateAdapter;
    TextView textView;
    StringBuilder sb = new StringBuilder();
    Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridView = findViewById(R.id.gridView);
        calendar = Calendar.getInstance();
        textView = findViewById(R.id.textView);
        textView.setText(sb);
        dateItemList = DateUtils.getDateList(calendar);
        updateTitle();
        dateAdapter = new DateAdapter(this, dateItemList, new OnDateCheckedListener() {
            @Override
            public void onDateChecked(int position, DateItem dateItem) {
                sb.setLength(0);
                for (DateItem item : dateAdapter.getCheckedList()) {
                    sb.append(item.toString())
                            .append(" ");
                }
                textView.setText(sb);
            }
        });
        gridView.setAdapter(dateAdapter);
        findViewById(R.id.button1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //上个月
                calendar.add(Calendar.MONTH, -1);
                dateItemList.clear();
                dateItemList.addAll(DateUtils.getDateList(calendar));
                dateAdapter.notifyDataSetChanged();
                updateTitle();
            }
        });
        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //下个月
                calendar.add(Calendar.MONTH, 1);
                dateItemList.clear();
                dateItemList.addAll(DateUtils.getDateList(calendar));
                dateAdapter.notifyDataSetChanged();
                updateTitle();
            }
        });
    }

    private void updateTitle() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINESE);
        setTitle(sdf.format(calendar.getTime()));
    }

}
