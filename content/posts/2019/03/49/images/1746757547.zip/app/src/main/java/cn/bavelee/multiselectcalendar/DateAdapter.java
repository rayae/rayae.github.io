package cn.bavelee.multiselectcalendar;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class DateAdapter extends BaseAdapter {
    Context context;
    List<DateItem> dateItemList;
    List<DateItem> checkedItemList = new ArrayList<>();
    OnDateCheckedListener onDateCheckedListener;

    public DateAdapter(Context context, List<DateItem> dateItemList, OnDateCheckedListener onDateCheckedListener) {
        this.context = context;
        this.dateItemList = dateItemList;
        this.onDateCheckedListener = onDateCheckedListener;
    }

    public List<DateItem> getCheckedList() {
        return checkedItemList;
    }

    @Override
    public int getCount() {
        return dateItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return dateItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        TextView textView = null;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.date_item, null, false);
        }
        textView = (TextView) convertView;

        final DateItem dateItem = (DateItem) getItem(position);
        textView.setText(dateItem.getDay());
        textView.setTextColor(dateItem.isCurrentMonth() ? Color.BLACK : Color.GRAY);

        if (dateItem.isChecked()) {
            textView.setBackgroundColor(Color.RED);
        } else {
            textView.setBackgroundResource(R.drawable.background_border);
        }
        if (dateItem.isCurrentMonth()) {
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (dateItem.isChecked()) {
                        dateItem.setChecked(false);
                        checkedItemList.remove(dateItem);
                    } else {
                        dateItem.setChecked(true);
                        checkedItemList.add(dateItem);
                    }
                    onDateCheckedListener.onDateChecked(position, dateItem);
                    notifyDataSetChanged();
                }
            });
        } else {
            textView.setOnClickListener(null);
        }
        return convertView;
    }
}
