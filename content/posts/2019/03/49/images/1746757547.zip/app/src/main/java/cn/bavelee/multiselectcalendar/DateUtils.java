package cn.bavelee.multiselectcalendar;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DateUtils {

    public static List<DateItem> getDateList(Calendar calendar) {
        List<DateItem> list = new ArrayList<>();
        //今天是星期几
        //1-Sunday 2-Monday ... 7-Saturday
        int today = calendar.get(Calendar.DAY_OF_MONTH);
        //每个月的第一天是星期几,将日期设置为1号进行获取
        calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), 1);
        int startIndex = calendar.get(Calendar.DAY_OF_WEEK) - 1;
        //每个月有多少天
        int totalDays = countDaysOfMonth(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH));
        //一行有7个日期
        //当前月份的第一天索引为startIndex
        String year = String.valueOf(calendar.get(Calendar.YEAR));
        String month = String.valueOf(calendar.get(Calendar.MONTH));

        //将0到startIndex的日期设置为空
        for (int i = 0; i < startIndex; i++) {
            DateItem dateItem = new DateItem();
            dateItem.setCurrentMonth(false);
            dateItem.setDay("");
            dateItem.setYear(year);
            dateItem.setMonth(month);
            list.add(dateItem);
        }
        //添加当前月份
        for (int i = 1; i <= totalDays; i++) {
            DateItem dateItem = new DateItem();
            dateItem.setYear(year);
            dateItem.setMonth(month);
            dateItem.setDay(String.valueOf(i));
            dateItem.setCurrentMonth(true);
            list.add(dateItem);
        }
        //最后需要填充的日期数量为 7 减去 totalDays + startIndex 除以 7 的余数
        int c = (7 - (totalDays + startIndex) % 7);
        if (c == 7) c = 0;
        for (int i = 0; i < c; i++) {
            DateItem dateItem = new DateItem();
            dateItem.setCurrentMonth(false);
            dateItem.setYear(year);
            dateItem.setDay("");
            dateItem.setMonth(month);
            list.add(dateItem);
        }
        return list;
    }

    //计算这个月有多少天
    private static int countDaysOfMonth(int year, int month) {
        switch (++month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                return 31;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            case 2:
                return (year % 4 == 0 && year % 100 != 0) ? 29 : 28;
            default:
                return 0;
        }
    }
}
