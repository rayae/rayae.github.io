package cn.bavelee.achartengineexamples;

import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

import org.achartengine.ChartFactory;
import org.achartengine.chart.BarChart;
import org.achartengine.model.CategorySeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import java.text.NumberFormat;
import java.util.List;

public class PieChartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        FrameLayout frameLayout = findViewById(R.id.frameLayout);
        frameLayout.addView(createMultiSeriesPieChart(Utils.getRandomDataList(), Utils.getRandomColorList(), Utils.getRandomTitleList()));

    }

    private View createMultiSeriesPieChart(List<Double> dataList, List<Integer> colorList, List<String> titleList) {
        DefaultRenderer renderer = new DefaultRenderer();
        CategorySeries categorySeries = new CategorySeries("PIE");


        //遍历每个序列创建对应的series和renderer
        for (int i = 0; i < dataList.size(); i++) {

            categorySeries.add(titleList.get(i), dataList.get(i));

            //饼图使用 SimpleSeriesRenderer
            SimpleSeriesRenderer r1 = new SimpleSeriesRenderer();
            r1.setColor(colorList.get(i));
            //设置value格式化输出为百分比，传入的值大于1会出问题
            //r1.setChartValuesFormat(NumberFormat.getPercentInstance());

            renderer.addSeriesRenderer(r1);
        }
        //显示标签
        renderer.setShowLabels(true);
        //显示数值
        renderer.setDisplayValues(true);
        //显示图例
        renderer.setShowLegend(true);
        //图例文本大小
        renderer.setLegendTextSize(25f);
        //设置不允许拖动
        renderer.setPanEnabled(false);
        //设置不允许缩放
        renderer.setZoomEnabled(false);
        //设置背景色，两个方法必须一起调用
        renderer.setBackgroundColor(Color.WHITE);
        renderer.setApplyBackgroundColor(true);
        //边距颜色，默认是黑色
        //四周边距，对应上左下右,要么不填要么就填四个值
        renderer.setMargins(new int[]{50, 50, 50, 50});
        //文本大小
        renderer.setLabelsTextSize(25f);

        return ChartFactory.getPieChartView(this, categorySeries, renderer);
    }
}
