package cn.bavelee.achartengineexamples;

import android.graphics.Color;

import java.util.ArrayList;
import java.util.List;

public class Utils {

    public static double minInList(List<Double> list) {
        double m = list.get(0);
        for (double d : list)
            if (m > d)
                m = d;
        return m;
    }

    public static double maxInList(List<Double> list) {
        double m = list.get(0);
        for (double d : list)
            if (m < d)
                m = d;
        return m;
    }

    public static List<Double> getRandomDataList() {
        List<Double> list = new ArrayList<>();
        list.add(10d);
        list.add(40d);
        list.add(50d);
        list.add(10d);
        list.add(50d);
        list.add(15d);
        list.add(51d);
        list.add(16d);
        list.add(57d);
        list.add(34d);
        return list;
    }

    public static List<Integer> getRandomColorList() {
        List<Integer> list = new ArrayList<>();
        list.add(Color.RED);
        list.add(Color.YELLOW);
        list.add(Color.BLACK);
        list.add(Color.BLUE);
        list.add(Color.CYAN);
        list.add(Color.DKGRAY);
        list.add(Color.LTGRAY);
        list.add(Color.MAGENTA);
        list.add(Color.GREEN);
        list.add(Color.GRAY);
        list.add(Color.RED);
        return list;
    }

    public static List<String> getRandomTitleList() {
        List<String> list = new ArrayList<>();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        list.add("F");
        list.add("G");
        list.add("H");
        list.add("I");
        list.add("J");
        return list;
    }
}
