package cn.bavelee.achartengineexamples;

import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;

import org.achartengine.ChartFactory;
import org.achartengine.chart.BarChart;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class BarChartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        FrameLayout frameLayout = findViewById(R.id.frameLayout);
        frameLayout.addView(createMultiSeriesBarChart(Utils.getRandomDataList(), Utils.getRandomColorList(), Utils.getRandomTitleList()));

    }

    private View createMultiSeriesBarChart(List<Double> dataList, List<Integer> colorList, List<String> titleList) {
        XYMultipleSeriesRenderer renderer = new XYMultipleSeriesRenderer();
        XYMultipleSeriesDataset dataSet = new XYMultipleSeriesDataset();

        //生成序列是获取数据中的最大最小值，用于决定y轴的起始值和结束值
        double max = 0;
        double min = 0;
        //遍历每个序列创建对应的series和renderer
        for (int i = 0; i < dataList.size(); i++) {
            int color = colorList.get(i);
            String title = titleList.get(i);

            XYSeriesRenderer r1 = new XYSeriesRenderer();
            XYSeries series = new XYSeries(title);

            //判断最大最小值
            double d = dataList.get(i);
            if (max < d)
                max = d;
            if (min > d)
                min = d;

            series.add(i, d);

            //颜色、文本大小、显示数值
            r1.setColor(color);
            r1.setChartValuesTextSize(25f);
            r1.setDisplayChartValues(true);
            //柱状图文本对齐方式
            r1.setChartValuesTextAlign(Paint.Align.CENTER);

            renderer.addSeriesRenderer(r1);
            dataSet.addSeries(series);
        }
        //设置x轴起始值和结束值,比临界值大一点可以更好的展示图表数据
        renderer.setXAxisMin(-1);
        renderer.setXAxisMax(dataList.size() + 1);

        //柱状图宽度
        renderer.setBarWidth(20f);
        //柱状图方向,横向的会导致图标拉伸
//        renderer.setOrientation(XYMultipleSeriesRenderer.Orientation.VERTICAL);
        //最大的和最小的值，比当前数值大10%…可以更好的展示图标数据
        renderer.setYAxisMax(max + max * 0.1);
        renderer.setYAxisMin(min - min * 0.1);
        //设置x,y轴的刻度数量
        renderer.setYLabels(8);
        renderer.setXLabels(dataList.size() + 3);
        //显示图例
        renderer.setShowLegend(true);
        //图例文本大小
        renderer.setLegendTextSize(25f);
        //设置不允许拖动
        renderer.setPanEnabled(false);
        //设置不允许缩放
        renderer.setZoomEnabled(false);
        //文本角度
        renderer.setXLabelsAngle(90);
        //设置背景色，两个方法必须一起调用
        renderer.setBackgroundColor(Color.WHITE);
        renderer.setApplyBackgroundColor(true);
        //边距颜色，默认是黑色
        renderer.setMarginsColor(Color.WHITE);
        //四周边距，对应上左下右,要么不填要么就填四个值
        renderer.setMargins(new int[]{50, 50, 50, 50});
        //文本大小
        renderer.setLabelsTextSize(25f);

        //BarChart.Type有两种
        //BarChart.Type.STACKED下图表上的文本对齐效果更好
        return ChartFactory.getBarChartView(this, dataSet, renderer, BarChart.Type.STACKED);
    }
}
